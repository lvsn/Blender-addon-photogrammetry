""" Contains general utility functions. """
