""" Contains data types used to represent reconstruction results. """
